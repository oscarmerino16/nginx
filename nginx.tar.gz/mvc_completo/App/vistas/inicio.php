<?php require_once RUTA_APP.'/vistas/inc/header.php' ?>

<div class="container">
  <div class="jumbotron">
    <h1>Estructura MVC en PHP</h1>
    <p>Modulo: DWES</p>
  </div>    
  <p>CPIFP Bajo Aragón</p>
</div>

<?php require_once RUTA_APP.'/vistas/inc/footer.php' ?>