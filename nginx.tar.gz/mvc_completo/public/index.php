<?php
    // Cargamos el iniciador
    require_once '../App/iniciador.php';

    // Instanciamos la clase Core
    $iniciar = new Core;

